class Example {
	render () {
		return (
			<div>
				<h1 class="test common" id="testID common">heading</h1>
				<h1 className="test common">heading</h1>
				<div class="container">
					{/* <!-- comment --> */}
					<span id="test-2" />
				</div>
			</div>
		);
	}
}