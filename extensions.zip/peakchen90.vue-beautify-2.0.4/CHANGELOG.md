## [release]

### 2.0.3: 24 Mar 2017
* Fix bug: If the shortcut key is the same as the vscode built-in shortcut key, in other non-vue files can not work.

### 2.0.1: 23 Mar 2017
* Fix bug: If the template's lang attribute is pug or jade, will make it chaotic.

### 2.0.0: 17 Mar 2017
* Notice: Now, please install [vetur](https://marketplace.visualstudio.com/items?itemName=octref.vetur), it has smilar features. 

### 1.0.5: 16 Mar 2017
* Fix bug: If the style's lang attribute is stylus or sass, will make it chaotic.

### 1.0.2: 15 Mar 2017
* Add:  `Beautify Vue` menu on vue file.

### 1.0.0: 14 Mar 2017
* Add: Format the vue file.