### Environment

  * VSCode Version: ...
  * OS Version: ...

### Actual behavior

...

### Expected behavior

...

### Steps to reproduce

...

### Config

```js
// Paste your configuration here.
```
